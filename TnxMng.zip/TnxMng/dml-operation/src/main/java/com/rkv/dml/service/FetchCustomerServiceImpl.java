package com.rkv.dml.service;

import com.rkv.dml.exception.CustomerNotFoundException;
import com.rkv.dml.exception.NoRecordFoundException;
import com.rkv.dml.model.CustomerDetailsDO;
import com.rkv.dml.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FetchCustomerServiceImpl implements FetchCustomerService {

    @Autowired
    CustomerRepository repository;


    @Override
    public CustomerDetailsDO findOneCustomer(Long customerID) {

        CustomerDetailsDO customer = repository.findById(customerID).orElseThrow(() ->
                new CustomerNotFoundException("Customer details does not exist"));

        return customer;
    }

    @Override
    public List<CustomerDetailsDO> findAllCustomer() {
        List<CustomerDetailsDO> customerDetailsDOList=new ArrayList<>();
        repository.findAll().iterator().forEachRemaining(customerDetailsDO ->
                customerDetailsDOList.add(customerDetailsDO) );

        if(customerDetailsDOList==null)
            throw  new NoRecordFoundException("No record found in customer database");

        return customerDetailsDOList;
    }
}
