package com.rkv.dml.controller;


import com.rkv.dml.model.CustomerDetailsDO;
import com.rkv.dml.service.FetchCustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    FetchCustomerService customerService;

    @GetMapping("/customer/{customerId}")
    private CustomerDetailsDO customerRegistration(@PathVariable Long customerId)
    {
        CustomerDetailsDO resCustomerDetails=customerService.findOneCustomer(customerId);
        return resCustomerDetails;
    }


    @GetMapping("/customerList")
    private List<CustomerDetailsDO> customerRegistration()
    {
        List<CustomerDetailsDO> resCustomerDetails=customerService.findAllCustomer();
        return resCustomerDetails;
    }

}
