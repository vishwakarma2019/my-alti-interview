package com.rkv.dml.repository;

import com.rkv.dml.model.CustomerDetailsDO;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends CrudRepository<CustomerDetailsDO,Long> {
}
