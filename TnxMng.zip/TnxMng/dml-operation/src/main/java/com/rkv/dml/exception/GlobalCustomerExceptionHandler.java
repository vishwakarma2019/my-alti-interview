package com.rkv.dml.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalCustomerExceptionHandler {

    @ExceptionHandler(value = CustomerNotFoundException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public @ResponseBody ErrorResponse handleCustomerNotFoundException(CustomerNotFoundException ex) {
        return new ErrorResponse(HttpStatus.CONFLICT.value(), ex.getMessage());
    }

    @ExceptionHandler(value = NoRecordFoundException.class)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public @ResponseBody ErrorResponse handleNoRecordFoundException(NoRecordFoundException ex) {
        return new ErrorResponse(HttpStatus.NO_CONTENT.value(), ex.getMessage());
    }
}