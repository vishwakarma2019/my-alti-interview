package com.rkv.dml.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class RegistrationModel {
    private String name;
    private String email;
    private int age;
    private Double balance;
}
