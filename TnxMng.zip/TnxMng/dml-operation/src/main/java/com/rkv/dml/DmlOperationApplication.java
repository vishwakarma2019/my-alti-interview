package com.rkv.dml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmlOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmlOperationApplication.class, args);
	}

}
