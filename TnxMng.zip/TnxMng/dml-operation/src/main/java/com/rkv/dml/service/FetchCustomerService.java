package com.rkv.dml.service;

import com.rkv.dml.model.CustomerDetailsDO;
import com.rkv.dml.model.RegistrationModel;

import java.util.List;

public interface FetchCustomerService {
    public CustomerDetailsDO findOneCustomer(Long customerId);
    public List<CustomerDetailsDO> findAllCustomer();
}
