package com.rkv.dml.exception;


public class NoRecordFoundException extends RuntimeException{
    private String message;

    public NoRecordFoundException() {}

    public NoRecordFoundException(String msg) {
        super(msg);
        this.message = msg;
    }

}
