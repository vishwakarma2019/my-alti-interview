package com.rkv.dml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmlOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
