
Post
localhost:8080/register

{
"name":"Abc Vishwkarma",
"email":"raj@gmail.com",
"age":"36",
"balance":10000
}

response
-----------
{
"customerId": 3,
"password": "24798",
"accountId": 24798,
"name": "Abc Vishwkarma",
"age": 36,
"balance": 10000.0,
"email": "raj@gmail.com"
}


Request
---------
localhost:8080/updateBalance/2/200.00

Response
-----------------
{
"customerId": 2,
"password": "21489",
"accountId": 21489,
"name": "Abc Vishwkarma",
"age": 36,
"balance": 9800.0,
"email": "raj@gmail.com"
}