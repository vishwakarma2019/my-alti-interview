package com.rkv.ddl.service;

import com.rkv.ddl.exception.CustomerNotFoundException;
import com.rkv.ddl.model.CustomerDetailsDO;
import com.rkv.ddl.model.RegistrationModel;
import com.rkv.ddl.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomerRepository repository;
    @Override
    public CustomerDetailsDO saveCustomerDetails(RegistrationModel registrationModel) {

        CustomerDetailsDO customer=new CustomerDetailsDO();
        customer.setName(registrationModel.getName());
        customer.setPassword(generated()+"");
        customer.setAge(registrationModel.getAge());
        customer.setAccountId(generated());
        customer.setBalance(registrationModel.getBalance());
        customer.setEmail(registrationModel.getEmail());

        return repository.save(customer);
    }


    @Override
    public CustomerDetailsDO updateBalance(Long customerID, Double amount) {

        CustomerDetailsDO customer = repository.findById(customerID).orElseThrow(() ->
                new CustomerNotFoundException("Customer details does not exist"));

        customer.setBalance(customer.getBalance()+amount);
        return repository.save(customer);
    }



    private int generated()
    {
        Random r = new Random( System.currentTimeMillis() );
        return ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
    }

}
