package com.rkv.ddl.controller;

import com.rkv.ddl.model.CustomerDetailsDO;
import com.rkv.ddl.service.CustomerService;
import com.rkv.ddl.model.RegistrationModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/register")
    private CustomerDetailsDO customerRegistration(@RequestBody RegistrationModel registrationModel)
    {
        CustomerDetailsDO resCustomerDetails=customerService.saveCustomerDetails(registrationModel);
        return resCustomerDetails;
    }


    @PostMapping("/updateBalance/{customerId}/{amount}")
    private CustomerDetailsDO customerRegistration(@PathVariable Long customerId ,@PathVariable Double amount)
    {
        CustomerDetailsDO resCustomerDetails=customerService.updateBalance(customerId,amount);
        return resCustomerDetails;
    }



}
