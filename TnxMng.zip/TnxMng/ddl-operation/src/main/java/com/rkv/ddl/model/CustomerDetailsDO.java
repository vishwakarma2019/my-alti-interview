package com.rkv.ddl.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;


@Entity(name = "CustomerDetails")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class CustomerDetailsDO {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long customerId;
    private String password;
    private Integer accountId;
    private String name;
    private Integer age;
    private Double balance;
    private String email;

}
