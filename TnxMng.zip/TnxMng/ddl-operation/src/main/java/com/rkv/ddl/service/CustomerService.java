package com.rkv.ddl.service;

import com.rkv.ddl.model.CustomerDetailsDO;
import com.rkv.ddl.model.RegistrationModel;

public interface CustomerService {
    public CustomerDetailsDO saveCustomerDetails(RegistrationModel registrationModel);
    public CustomerDetailsDO updateBalance(Long customerID, Double amount);
}
