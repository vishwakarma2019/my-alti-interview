package com.rkv.ddl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DdlOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DdlOperationApplication.class, args);
	}

}
